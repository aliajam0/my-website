import mongoose from "mongoose";

const categorySchema = new mongoose.Schema(
  {
    name_ar: {
      type: String,
      required: true,
      trim: true,
    },

    key: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    mainCategory: {
      type: String,
      required: true,
      trim: true,
    },

    //CATEGORY IMAGE
    image: {
      type: String,
      default: "",
    },
  },
  { timestamps: true }
);

export default mongoose.model("Category", categorySchema);
