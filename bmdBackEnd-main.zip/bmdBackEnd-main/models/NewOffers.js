import mongoose from "mongoose";

const newOffersSchema = new mongoose.Schema(
  {
    image: {
      type: String,
      required: true,
      trim: true,
    },

    shortDescription: {
      type: String,
      required: false,
      trim: true,
    },

    longDescription: {
      type: String,
      required: false,
      trim: true,
    },
    urlLink: {
      type: String,
      required: true,
      trim: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("newOffer", newOffersSchema);
