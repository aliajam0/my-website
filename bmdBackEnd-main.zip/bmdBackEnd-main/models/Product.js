import mongoose from "mongoose";

const productSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    price: { type: Number, required: true },
    oldPrice: { type: Number },
    stockStatus: { type: String, default: "متوفر" },
    subcategory: { type: String, required: true }, // slug for front-end
    mainCategory: { type: String, required: true }, // filled from Category
    category: { type: mongoose.Schema.Types.ObjectId, ref: "Category", required: true },
    image: { type: String },
    images: { type: [String], default: [] },
    shortDescription: { type: String },
    longDescription: { type: String },
    sale: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export default mongoose.model("Product", productSchema);
