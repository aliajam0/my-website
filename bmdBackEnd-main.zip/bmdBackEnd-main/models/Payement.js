import mongoose from "mongoose";

const newPayementSchema = new mongoose.Schema(
  {
    image: {
      type: String,
      required: true,
      trim: true,
    },

    Description: {
      type: String,
      required: true,
      trim: true,
    },
    longDescription: {
      type: String,
      required: false,
      trim: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("payement", newPayementSchema);
