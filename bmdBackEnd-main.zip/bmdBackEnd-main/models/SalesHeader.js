import mongoose from "mongoose";

const salesHeaderSchema = new mongoose.Schema({
  images: {
    type: [String],
    required: [true, "Images array required"],
    validate: v => v.length === 2
  },
  urlLink: {
    type: String,
    required: true,
  },

}, { timestamps: true });

export default mongoose.model("sales", salesHeaderSchema);
