import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import User from "./models/User.js";

// Routes
import productRoutes from "./routes/public/productRoutes.js";
import adminProductRoutes from "./routes/admin/adminRoutes.js";

import authRoutes from "./routes/public/authroutes.js";
import favRoutes from "./routes/public/favRoutes.js";

import offersRoutes from "./routes/public/newOffersRoutes.js";
import salesRoutes from "./routes/public/salesHeaderRoutes.js";
import offersAdminRoutes from "./routes/admin/offersAdminRoutes.js";
import salesAdminRoutes from "./routes/admin/salesAdminRoutes.js";

import faqRoutes from "./routes/public/faqRoutes.js";
import faqAdminRoutes from "./routes/admin/faqAdminRoutes.js";

import categoryRoutes from "./routes/public/categoriesRoutes.js"
import categoriesAdminRoutes from "./routes/admin/categoriesAdminRoutes.js";

import payementRoutes from './routes/public/payementRoutes.js'
import payementAdminRoutes from './routes/admin/payementAdminRoutes.js'


dotenv.config();
const app = express();

const emailAdmin = process.env.emailAdmin;
const passAdmin = process.env.passAdmin;

// Middleware
app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "https://digital-e-commerce-jieh.vercel.app",
    ],
    credentials: true,
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.use(express.json());

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(async () => {
    console.log("✅ MongoDB connected");

    // Ensure admin user exists
    const adminExists = await User.findOne({ email: emailAdmin });
    if (!adminExists) {
      const hashedPassword = await bcrypt.hash(passAdmin, 10);
      await User.create({
        name: "Admin",
        email: emailAdmin,
        password: hashedPassword,
        role: "admin",
      });
      console.log("👑 Admin user created");
    }
  })
  .catch((err) => console.error("❌ MongoDB connection error:", err));

// =================== Public Routes ===================
app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/offers", offersRoutes);
app.use("/api/sales", salesRoutes);
app.use("/api/faq", faqRoutes);
app.use("/api/user", favRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/payement", payementRoutes);

// =================== Admin Routes ===================
app.use("/api/admin/products", adminProductRoutes);
app.use("/api/admin/offers", offersAdminRoutes);
app.use("/api/admin/sales", salesAdminRoutes);
app.use("/api/admin/faq", faqAdminRoutes);
app.use("/api/admin/categories", categoriesAdminRoutes);
app.use("/api/admin/payement", payementAdminRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Internal server error", error: err.message });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
