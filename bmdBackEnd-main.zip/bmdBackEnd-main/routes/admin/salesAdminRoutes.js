import express from "express";
import Sales from "../../models/SalesHeader.js";
import verifyAdmin from "../../middleware/verifyToken.js";

const router = express.Router();

// Add sales header (desktop + mobile images)
router.post("/", verifyAdmin, async (req, res) => {
  try {
    const { images, urlLink } = req.body;

    if (!urlLink) {
      return res.status(400).json({ message: "urlLink is required" });
    }

    if (!Array.isArray(images) || images.length !== 2) {
      return res.status(400).json({ message: "images must be an array of 2 URLs (desktop + mobile)" });
    }

    const sales = new Sales({ images, urlLink });
    await sales.save();

    res.status(201).json({ message: "Sales header added", sales });
  } catch (err) {
    res.status(500).json({ message: "Error adding sales header", error: err.message });
  }
});

// Update sales header
router.put("/:id", verifyAdmin, async (req, res) => {
  try {
    const updated = await Sales.findByIdAndUpdate(req.params.id, req.body, { new: true });

    if (!updated) return res.status(404).json({ message: "Sales header not found" });

    res.json({ message: "Sales header updated", updated });
  } catch (err) {
    res.status(500).json({ message: "Failed to update", error: err.message });
  }
});

// Delete sales header
router.delete("/:id", verifyAdmin, async (req, res) => {
  try {
    const deleted = await Sales.findByIdAndDelete(req.params.id);

    if (!deleted) return res.status(404).json({ message: "Sales header not found" });

    res.json({ message: "Sales header deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete", error: err.message });
  }
});

export default router;
