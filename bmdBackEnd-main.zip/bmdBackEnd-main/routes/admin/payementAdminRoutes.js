import express from "express";
import Payement from "../../models/Payement.js";
import verifyAdmin from "../../middleware/verifyToken.js";

const router = express.Router();

router.post("/", verifyAdmin, async (req, res) => {
  try {
    const { image, Description, longDescription } = req.body;

    if (!image || !Description) {
      return res.status(400).json({ message: "Image and description are required" });
    }

    const created = new Payement({
      image,
      Description,
      longDescription,
    });

    await created.save();
    res.status(201).json({ message: "Payment instructions added", data: created });
  } catch (err) {
    res.status(500).json({ message: "Error creating payment instructions", error: err.message });
  }
});

// --- Update payment instructions (ADMIN) ---
router.put("/:id", verifyAdmin, async (req, res) => {
  try {
    const updated = await Payement.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updated) return res.status(404).json({ message: "Item not found" });

    res.json({ message: "Updated successfully", data: updated });
  } catch (err) {
    res.status(500).json({ message: "Error updating", error: err.message });
  }
});

// --- Delete payment instructions (ADMIN) ---
router.delete("/:id", verifyAdmin, async (req, res) => {
  try {
    const deleted = await Payement.findByIdAndDelete(req.params.id);

    if (!deleted) return res.status(404).json({ message: "Item not found" });

    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Error deleting", error: err.message });
  }
});

export default router;
