import express from "express";
import Category from "../../models/Category.js";
import verifyAdmin from "../../middleware/verifyToken.js";

const router = express.Router();

// ADD CATEGORY (Admin)
router.post("/add", verifyAdmin, async (req, res) => {
  try {
    // req.body should include: name_ar, key, mainCategory, image
    const category = await Category.create(req.body);
    res.status(201).json(category);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// UPDATE CATEGORY (Admin)
router.put("/update/:id", verifyAdmin, async (req, res) => {
  try {
    const updated = await Category.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ message: "Category not found" });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE CATEGORY (Admin)
router.delete("/delete/:id", verifyAdmin, async (req, res) => {
  try {
    const deleted = await Category.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Category not found" });
    res.json({ message: "Category deleted" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
