import express from "express";
import Product from "../../models/Product.js";
import Category from "../../models/Category.js";
import verifyAdmin from "../../middleware/verifyToken.js";

const router = express.Router();

// Create product
router.post("/", verifyAdmin, async (req, res) => {
  try {
    const {
      title,
      price,
      oldPrice,
      stockStatus,
      subcategory,
      category,
      image,
      images,
      shortDescription,
      longDescription,
      sale,
    } = req.body;

    const categoryDoc = await Category.findById(category);
    if (!categoryDoc) {
      return res.status(400).json({ message: "Invalid category ID" });
    }

    const newProduct = new Product({
      title,
      price,
      oldPrice,
      stockStatus,
      subcategory,
      category,
      mainCategory: categoryDoc.mainCategory,
      image,
      images: Array.isArray(images) ? images : [],
      shortDescription,
      longDescription,
      sale: sale || 0,
    });

    const saved = await newProduct.save();

    res.status(201).json({
      message: "Product created successfully",
      product: saved,
    });
  } catch (err) {
    res.status(500).json({ message: "Failed to create product", error: err.message });
  }
});

// Update product
router.put("/:id", verifyAdmin, async (req, res) => {
  try {
    const data = req.body;

    if (data.category) {
      const categoryDoc = await Category.findById(data.category);
      if (!categoryDoc) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      data.mainCategory = categoryDoc.mainCategory;
    }

    if (data.images && !Array.isArray(data.images)) {
      return res.status(400).json({ message: "Images must be an array" });
    }

    const updated = await Product.findByIdAndUpdate(req.params.id, data, { new: true });

    if (!updated)
      return res.status(404).json({ message: "Product not found" });

    res.json({ message: "Product updated successfully", product: updated });
  } catch (err) {
    res.status(500).json({ message: "Error updating product", error: err.message });
  }
});


// Delete product
router.delete("/:id", verifyAdmin, async (req, res) => {
  try {
    const deleted = await Product.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Product not found" });

    res.json({ message: "Product deleted successfully" });

  } catch (err) {
    res.status(500).json({ 
      message: "Failed to delete product", 
      error: err.message 
    });
  }
});

export default router;
