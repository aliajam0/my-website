import express from "express";
import FAQ from "../../models/FAQsec.js";
import verifyAdmin from "../../middleware/verifyToken.js";

const router = express.Router();

// Create FAQ
router.post("/", verifyAdmin, async (req, res) => {
  try {
    const { question, answer } = req.body;

    if (!question || !answer) {
      return res.status(400).json({ message: "Question and answer are required" });
    }

    const faq = new FAQ({ question, answer });
    await faq.save();

    res.status(201).json(faq);
  } catch (err) {
    console.error(err); // log the real error
    res.status(500).json({ message: "Error creating FAQ", error: err.message });
  }
});

// Update FAQ
router.put("/:id", verifyAdmin, async (req, res) => {
  try {
    const faq = await FAQ.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    res.json(faq);
  } catch (err) {
    res.status(400).json({ message: "Error updating FAQ" });
  }
});

// Delete FAQ
router.delete("/:id", verifyAdmin, async (req, res) => {
  try {
    await FAQ.findByIdAndDelete(req.params.id);
    res.json({ message: "FAQ deleted successfully" });
  } catch (err) {
    res.status(400).json({ message: "Error deleting FAQ" });
  }
});

export default router;