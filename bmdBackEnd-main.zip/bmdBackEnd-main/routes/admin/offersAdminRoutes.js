import express from "express";
import Offers from "../../models/NewOffers.js";
import verifyAdmin from "../../middleware/verifyToken.js";

const router = express.Router();

// Create offer
router.post("/", verifyAdmin, async (req, res) => {
  try {
    const { image, shortDescription, longDescription, urlLink } = req.body;

    if (!image || !shortDescription || !longDescription || !urlLink) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const offer = new Offers({ image, shortDescription, longDescription, urlLink });
    await offer.save();

    res.status(201).json({ message: "Offer added successfully", offer });
  } catch (err) {
    res.status(500).json({ message: "Error creating offer", error: err.message });
  }
});

// Update offer
router.put("/:id", verifyAdmin, async (req, res) => {
  try {
    const data = req.body;

    const updated = await Offers.findByIdAndUpdate(req.params.id, data, { new: true });

    if (!updated) return res.status(404).json({ message: "Offer not found" });

    res.json({ message: "Offer updated successfully", updated });
  } catch (err) {
    res.status(500).json({ message: "Update failed", error: err.message });
  }
});

// Delete offer
router.delete("/:id", verifyAdmin, async (req, res) => {
  try {
    const deleted = await Offers.findByIdAndDelete(req.params.id);

    if (!deleted) return res.status(404).json({ message: "Offer not found" });

    res.json({ message: "Offer deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Delete failed", error: err.message });
  }
});

export default router;
