import express from "express";
import Category from "../../models/Category.js";
import Product from "../../models/Product.js";

const router = express.Router();

// GET all categories or main categories
// Example: GET /api/categories?mainCategory=true
router.get("/", async (req, res) => {
  try {
    const { mainCategory } = req.query;

    let categories;
    if (mainCategory === "true") {
      // Fetch only main categories
      categories = await Category.find({ mainCategory: { $ne: "" } });
    } else {
      categories = await Category.find();
    }

    res.json(categories);
  } catch (err) {
    res.status(500).json({ message: "Error fetching categories", error: err.message });
  }
});

// GET products by main category
// Example: GET /api/categories/products?mainCategory=entertainment
router.get("/products", async (req, res) => {
  try {
    const { mainCategory } = req.query;
    let products;

    if (mainCategory) {
      const categories = await Category.find({ mainCategory });
      const categoryIds = categories.map(c => c._id);

      products = await Product.find({ category: { $in: categoryIds } }).populate("category");
    } else {
      products = await Product.find().populate("category");
    }

    res.json(products);
  } catch (err) {
    res.status(500).json({ message: "Error fetching products", error: err.message });
  }
});

// GET products by category key (sub-category)
router.get("/products/by-key", async (req, res) => {
  try {
    const { categoryKey } = req.query;
    if (!categoryKey) {
      return res.status(400).json({ message: "categoryKey is required" });
    }

    const category = await Category.findOne({ key: categoryKey });
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }

    const products = await Product.find({ category: category._id }).populate("category");

    res.json(products);
  } catch (err) {
    res.status(500).json({
      message: "Error fetching products",
      error: err.message,
    });
  }
});


export default router;
