import express from "express";
import Sales from "../../models/SalesHeader.js";

const router = express.Router();

// Get all sales headers (public)
router.get("/", async (req, res) => {
  try {
    const sales = await Sales.find();
    res.json(sales);
  } catch (err) {
    res.status(500).json({ message: "Error fetching sales", error: err.message });
  }
});

export default router;
