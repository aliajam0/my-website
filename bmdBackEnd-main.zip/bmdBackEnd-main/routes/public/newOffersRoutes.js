import express from "express";
import Offers from "../../models/NewOffers.js";

const router = express.Router();

// Get all offers (public)
router.get("/", async (req, res) => {
  try {
    const offers = await Offers.find();
    res.json(offers);
  } catch (err) {
    res.status(500).json({ message: "Error fetching offers", error: err.message });
  }
});

export default router;
