import express from "express";
import Product from "../../models/Product.js";
import Category from "../../models/Category.js"; // make sure you import this

const router = express.Router();

// Get all products, optionally filtered by category or mainCategory
router.get("/", async (req, res) => {
  try {
    const { category, mainCategory } = req.query;
    let filter = {};

    if (category && category !== "all") {
      // filter by specific category key
      filter = { "category.key": category }; // only works if you store `key` inside category doc
    } else if (mainCategory && mainCategory !== "all") {
      // filter by main category
      const categories = await Category.find({ mainCategory });
      const categoryIds = categories.map((c) => c._id);
      filter = { category: { $in: categoryIds } };
    }

    const products = await Product.find(filter).populate("category");
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: "Error fetching products", error: err.message });
  }
});

// Get single product by ID
router.get("/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate("category");
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: "Error fetching product", error: err.message });
  }
});

export default router;
