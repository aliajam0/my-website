import express from "express";
import FAQ from "../../models/FAQsec.js";

const router = express.Router();

// PUBLIC — Get all FAQs
router.get("/", async (req, res) => {
  try {
    const faqs = await FAQ.find();
    res.json(faqs);
  } catch (err) {
    res.status(500).json({ message: "Error fetching FAQs" });
  }
});

export default router;
