import express from "express";
import Payement from "../../models/Payement.js";

const router = express.Router();

// --- Get all payment instructions (PUBLIC) ---
router.get("/", async (req, res) => {
  try {
    const data = await Payement.find().sort({ createdAt: -1 });
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ message: "Error fetching data", error: err.message });
  }
});

export default router;