import express from 'express';
import User from '../../models/User.js';
import authMiddleware from '../../middleware/userAuth.js';

const router = express.Router();

// Add/Remove favorite
router.post('/favorites/:productId', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  const { productId } = req.params;

  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    const index = user.favorites.indexOf(productId);
    if (index === -1) {
      user.favorites.push(productId); // add
    } else {
      user.favorites.splice(index, 1); // remove
    }

    await user.save();
    res.json({ favorites: user.favorites });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get user's favorites
router.get('/favorites', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate('favorites');
    res.json(user.favorites);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
